How to run code:
0. In the command line run: pip install gym==0.0.7

1. If you have Jupyter notebook installed on your machine
    a. download and decompress  tlee320.zip
    b. in terminal/command line navigate to directory while tlee320 is located
    c. in terminal/command line type "jupyter notebook"
      i. if a new broswer tab does not open automatically, copy and paste provided URL code from terminal/command line
    d. in browser click on prj4.ipynb
    e. in kernel tab, select "restart & run all"

2. If you do not have Jupyter Notebook installed
    a. go to http://jupyter.org/ and follow installation instructions
    b. go to section 1 of this document